# Product Development Lifecycle

The virtual tech org delivers products through 5 stages. Each stage has clear inputs, outputs, and a gate review before proceeding.

## Stage 0: Discovery

**Led by**: CEO (Alex)  
**Duration**: 1-3 conversation turns  
**Goal**: Turn a vague idea into a concrete product brief

### What Happens
The CEO runs a structured brainstorming session with the user. This is not a requirements dump — it's a conversation. The CEO asks questions, challenges assumptions, and helps the user think through what they actually need.

### Key Questions the CEO Asks
1. **The Problem**: What problem are we solving? Who has this problem?
2. **The User**: Who's the primary user? What does their day look like?
3. **The Core Flow**: What's the one thing this product absolutely must do?
4. **Success Metrics**: How will we know if this works?
5. **Constraints**: Budget? Timeline? Must-have tech? Existing systems to integrate with?
6. **Non-goals**: What are we explicitly NOT building? (This prevents scope creep later)

### CTO Involvement
The CTO listens during discovery and occasionally jumps in:
- "That's technically feasible, but it'll triple the timeline. Can we start simpler?"
- "If we use X instead of Y, we get that for free."
- "I'd want Drew to research whether an existing solution covers this before we build from scratch."

### Output: Product Brief

Save to `project/product-brief.md`:

```markdown
# Product Brief: [Project Name]

## Problem Statement
[1-2 sentences on the core problem]

## Target User
[Who uses this, what's their context]

## Core Features (MVP)
1. [Feature 1 — what it does, not how]
2. [Feature 2]
3. [Feature 3]
(Keep to 3-5 features maximum for MVP)

## Non-Goals
- [What we're explicitly not building]

## Success Criteria
- [Measurable outcome 1]
- [Measurable outcome 2]

## Constraints
- Tech: [any stack requirements]
- Timeline: [any deadlines]
- Integration: [existing systems]

## Open Questions
- [Things we still need to figure out]
```

### Gate Review
CEO presents the brief to the user: "Here's what I've distilled from our conversation. Does this capture it? Anything I'm missing or got wrong?"

User can approve, revise, or send back for more brainstorming.

---

## Stage 1: Architecture

**Led by**: CTO (Jordan) + Architect (Priya)  
**Duration**: 1-2 conversation turns  
**Goal**: Technical design that guides all subsequent development

### What Happens
The CTO takes the product brief and works with the Architect to design the system. The CTO presents the design to the user in plain language, with technical details available on request.

### Design Decisions to Make
1. **Architecture pattern**: Monolith? Microservices? Serverless? Modular monolith?
2. **Tech stack**: Languages, frameworks, databases, message queues
3. **Data model**: Core entities and their relationships
4. **API design**: REST? gRPC? GraphQL? What endpoints?
5. **Infrastructure**: Where does this run? How is it deployed?
6. **Security model**: Auth strategy, data protection, access control

### CTO Decision Framework
When choosing tech, the CTO considers:
- User's stated constraints and existing stack
- Team expertise (the ruflo agents work best with mainstream tech)
- Simplicity over cleverness (especially for prototype/MVP)
- What minimizes risk for the specific problem domain

### Output: Architecture Doc

Save to `project/architecture.md`:

```markdown
# Architecture: [Project Name]

## High-Level Design
[Diagram description or ASCII art showing major components]

## Tech Stack
- Language: [X] — [why]
- Framework: [X] — [why]  
- Database: [X] — [why]
- [Any other significant choices]

## Data Model
[Core entities, relationships, key fields]

## API Surface
[Main endpoints/operations with brief descriptions]

## Project Structure
[Directory layout]

## Deployment Strategy
[How it runs — dev, staging, prod]

## Key Design Decisions
| Decision | Choice | Rationale | Alternatives Considered |
|----------|--------|-----------|------------------------|
| ... | ... | ... | ... |
```

### Gate Review
CTO presents to the user: "Here's how we're going to build this. The key tradeoffs are [X]. Questions?"

If the user has strong tech opinions (like preferring Rust over Python), the CTO adjusts and explains any implications.

---

## Stage 2: Prototype

**Led by**: CTO (Jordan)  
**Team**: Architect (Priya), Backend Dev (Marcus), Frontend Dev (Lina)  
**Goal**: First working code — ugly but functional  
**Ruflo execution**: Yes — hive-mind swarm

### What Happens
This is where the rubber meets the road. The CTO spawns a small ruflo swarm to build a working prototype. Expectations are deliberately low — this is about proving the concept works, not about polish.

### Prototype Standards
- Core feature works end-to-end
- No auth, no error handling, no tests (those come in MVP)
- Hardcoded values are fine
- UI can be ugly / minimal
- README with "how to run it" is the only doc needed

### Ruflo Execution
The CTO generates a Stage 2 workflow (see ruflo-config.md) and runs it. The swarm typically runs:
1. Architect sets up project structure
2. Backend dev implements core logic (parallel with frontend if applicable)
3. Frontend dev builds minimal UI
4. CTO reviews output and assembles

### Output
- Working code in `project/prototype/`
- Basic README with run instructions
- CTO summary of what works and what's duct-taped

### Gate Review
CTO demos to the user: "Here's the prototype. [Feature X] works — try it. It's rough around the edges, but the core concept is solid. Ready to move to MVP?"

---

## Stage 3: MVP

**Led by**: CTO + VP Engineering (Sam)  
**Team**: Full engineering team minus Security and Performance  
**Goal**: Feature-complete for core use case, tested, deployable  
**Ruflo execution**: Yes — full hive-mind swarm

### What Happens
The team takes the prototype and turns it into a real product. This is the biggest stage — multiple agents working in coordinated parallel/sequential stages. **From this stage onward, ECC's engineering standards are enforced.**

### MVP Standards
- All core features from the product brief working
- Proper error handling
- Input validation on all user inputs (ECC security rule)
- No hardcoded secrets (ECC security rule)
- Basic auth if needed
- Unit and integration tests (80%+ coverage — ECC standard)
- TDD workflow: RED→GREEN→REFACTOR (ECC tdd-guide pattern)
- Conventional commits: `feat:`, `fix:`, `refactor:`, `test:`, `docs:` (ECC git-workflow rule)
- CI pipeline (even if simple)
- Clean code structure
- API documentation
- User-facing README

### Development Cycle (ECC-enforced)
Each feature within the MVP follows ECC's disciplined cycle:
1. **Plan** — Sam (planner) breaks the feature into implementation phases
2. **TDD** — Marcus/Lina write failing tests first, then implement
3. **Review** — Casey reviews code for quality, security, maintainability
4. **Fix** — Developers address CRITICAL and HIGH findings
5. **Ship** — Feature merged with conventional commit

### Ruflo Execution
The CTO generates a Stage 3 workflow (see ruflo-config.md). Typical execution:

**Phase 1: Foundation** (parallel)
- Architect refactors prototype into clean structure
- Backend dev implements remaining features
- Frontend dev builds proper UI

**Phase 2: Quality** (sequential after Phase 1)
- QA writes and runs tests
- Code reviewer reviews all code
- DevOps sets up CI/CD pipeline

**Phase 3: Documentation** (parallel with Phase 2)
- Technical writer creates docs
- CTO reviews overall quality

### Output
- Production-ready code in `project/mvp/`
- Tests passing
- CI/CD config
- API docs and README
- CTO summary with quality metrics

### Gate Review
CEO and CTO present together:
- CEO: "Here's what we built against the original brief. [Coverage of features]."
- CTO: "Tech quality report: tests pass, CI is green, code structure is clean. Here's what I'd improve before production."

---

## Stage 4: Production

**Led by**: CTO + VP Engineering  
**Team**: ALL roles active  
**Goal**: Production-hardened, secure, performant, fully documented  
**Ruflo execution**: Yes — full swarm with security and performance agents

### What Happens
The final stage adds the "ilities" — security, reliability, scalability, observability. This is where the full org earns its keep.

### Production Standards
- Security audit complete — Ash runs ECC's `/security-scan` protocol (OWASP Top 10, dependency CVEs, secret detection, input validation)
- Performance benchmarks meet targets (Taylor)
- Monitoring and alerting configured (Kai)
- Error recovery / graceful degradation
- Load testing passed
- E2E tests cover critical user flows — Robin runs ECC's `/e2e` protocol (Playwright)
- Complete documentation (Morgan) — synced with code via ECC's doc-updater pattern
- Deployment automation (Kai)
- Code review sign-off — Casey runs ECC's `/code-review` with CRITICAL/HIGH/MEDIUM/LOW ratings
- All CRITICAL and HIGH findings resolved before launch
- 80%+ test coverage maintained (ECC standard)
- Conventional commits throughout git history

### Ruflo Execution
The CTO generates a Stage 4 workflow (see ruflo-config.md). Typical execution:

**Phase 1: Audit** (parallel)
- Security engineer audits code + dependencies
- Performance engineer profiles and benchmarks
- Code reviewer does final review pass

**Phase 2: Harden** (sequential, based on audit findings)
- Backend/frontend devs fix security findings
- Performance engineer optimizes hot paths
- DevOps adds monitoring, logging, alerting

**Phase 3: Polish** (parallel)
- Technical writer completes all documentation
- DevOps finalizes deployment automation
- QA runs final regression suite

### Output
- Production code in `project/production/`
- Security audit report
- Performance benchmark results
- Complete documentation
- Deployment playbook
- Final CTO sign-off

### Gate Review
The CEO delivers a "launch brief":
- What we built
- How it meets the original success criteria
- Known limitations
- Recommended next steps (V2 features, scaling considerations)

The CTO adds a technical handover:
- How to run it
- How to deploy it
- How to monitor it
- What to watch out for

---

## Stage Skipping

Not every project needs all 5 stages. The CEO/CTO should recommend skipping when appropriate:

- **Quick script / utility**: Skip to Stage 2 (prototype = final product), add tests if non-trivial
- **Internal tool**: Stages 0-3, skip Stage 4 production hardening
- **User just wants a prototype**: Stages 0-2 only
- **Production system**: All stages

The CEO should explicitly confirm: "For this project, I'd recommend going through Stages 0-3 and skipping the full production hardening. Sound right?"

## Rollback

If a stage produces poor results:
1. CTO explains what went wrong
2. Options: re-run the stage, go back to previous stage, adjust scope
3. User decides (or CEO/CTO decide in auto-pilot mode)
4. The team re-executes with adjusted parameters

Never silently push forward with broken output.
