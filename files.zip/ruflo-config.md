# Ruflo Configuration Reference

This file contains the ruflo workflow templates and CLI commands the CTO uses to orchestrate the engineering team.

## Prerequisites

Ruflo should be available via npx. The CTO checks and initializes on first use:

```bash
# Check availability (try ruflo first, fall back to claude-flow)
RUFLO_CMD="npx ruflo@latest"
$RUFLO_CMD --version 2>/dev/null || {
  RUFLO_CMD="npx claude-flow@latest"
  $RUFLO_CMD --version 2>/dev/null || {
    echo "Installing ruflo..."
    npx ruflo@latest init --force
    RUFLO_CMD="npx ruflo@latest"
  }
}
```

## Quick Reference: Key Commands

```bash
# Initialize hive-mind
$RUFLO_CMD hive-mind init

# Spawn a swarm with an objective
$RUFLO_CMD hive-mind spawn "<objective>" --queen-type strategic --claude

# Run a workflow file
$RUFLO_CMD automation run-workflow <workflow.json> --claude --non-interactive --output-format stream-json

# Spawn specific agent types
$RUFLO_CMD swarm spawn researcher "<task>"
$RUFLO_CMD swarm spawn coder "<task>"
$RUFLO_CMD swarm spawn tester "<task>"
$RUFLO_CMD swarm spawn architect "<task>"
$RUFLO_CMD swarm spawn reviewer "<task>"
$RUFLO_CMD swarm spawn documenter "<task>"
$RUFLO_CMD swarm spawn optimizer "<task>"
$RUFLO_CMD swarm spawn analyst "<task>"

# Monitor
$RUFLO_CMD hive-mind status
$RUFLO_CMD hive-mind metrics
$RUFLO_CMD swarm status

# Memory (for shared state between agents)
$RUFLO_CMD memory store <key> "<value>" --namespace project
$RUFLO_CMD memory query "<search>" --namespace project
```

## Workflow Templates

### Stage 1: Architecture Workflow

This is a lightweight workflow — just the architect and researcher doing design work.

```json
{
  "name": "stage-1-architecture",
  "description": "Architecture design for {{PROJECT_NAME}}",
  "tasks": [
    {
      "id": "research",
      "assignTo": "researcher",
      "description": "Research best practices, existing solutions, and technology options for: {{PRODUCT_BRIEF_SUMMARY}}. Output a structured comparison of approaches with pros/cons.",
      "claudePrompt": "You are a senior technology researcher. Analyze the requirements and produce a technology evaluation report covering: architecture patterns, frameworks, databases, and deployment options. Focus on {{TECH_CONSTRAINTS}}. Be practical — recommend what works, not what's trendy."
    },
    {
      "id": "architecture",
      "assignTo": "architect",
      "depends": ["research"],
      "description": "Design the system architecture based on research findings. Produce: component diagram, data model, API surface, and project structure.",
      "claudePrompt": "You are a system architect. Using the research findings, design a clean, modular architecture for {{PROJECT_NAME}}. Produce: 1) High-level component diagram (ASCII), 2) Data model with entities and relationships, 3) API endpoint list with methods and descriptions, 4) Directory structure. Optimize for simplicity and maintainability."
    }
  ]
}
```

### Stage 2: Prototype Workflow

Small team, fast execution, minimal quality gates.

```json
{
  "name": "stage-2-prototype",
  "description": "Prototype build for {{PROJECT_NAME}}",
  "tasks": [
    {
      "id": "scaffold",
      "assignTo": "architect",
      "description": "Set up project structure, dependencies, and boilerplate based on the architecture doc.",
      "claudePrompt": "You are setting up the project scaffold for {{PROJECT_NAME}}. Create the directory structure, install dependencies, set up the build system, and create placeholder files. Tech stack: {{TECH_STACK}}. Output working boilerplate that builds and runs (even if it does nothing yet)."
    },
    {
      "id": "backend",
      "assignTo": "coder",
      "depends": ["scaffold"],
      "description": "Implement the core backend logic: {{CORE_FEATURES_BACKEND}}",
      "claudePrompt": "You are a senior backend developer. Implement the core backend for {{PROJECT_NAME}}. Focus on making {{PRIMARY_FEATURE}} work end-to-end. It's OK to hardcode values, skip error handling, and use simple patterns. The goal is a working prototype, not production code. Tech: {{BACKEND_STACK}}."
    },
    {
      "id": "frontend",
      "assignTo": "coder",
      "depends": ["scaffold"],
      "description": "Build minimal UI for {{CORE_FEATURES_FRONTEND}}",
      "claudePrompt": "You are a frontend developer. Build a minimal but functional UI for {{PROJECT_NAME}}. It needs to: {{UI_REQUIREMENTS}}. Keep it simple — no complex state management or animations. Make it work, worry about pretty later. Tech: {{FRONTEND_STACK}}."
    }
  ]
}
```

### Stage 3: MVP Workflow

Full team, phased execution with ECC quality gates between phases.

```json
{
  "name": "stage-3-mvp",
  "description": "MVP build for {{PROJECT_NAME}} — ECC standards enforced",
  "tasks": [
    {
      "id": "plan_features",
      "assignTo": "planner",
      "description": "Create implementation plan for all MVP features.",
      "claudePrompt": "You are a planner agent following ECC's planning protocol. For {{PROJECT_NAME}}, create an implementation plan: 1) Restate requirements from the product brief, 2) Identify risks and blockers, 3) Break into implementation phases with dependencies, 4) Estimate complexity per phase (Low/Medium/High). Output format: Implementation Plan markdown with Overview, Requirements, Architecture Changes, and Implementation Steps sections."
    },
    {
      "id": "refactor_structure",
      "assignTo": "architect",
      "depends": ["plan_features"],
      "description": "Refactor prototype into clean, modular structure suitable for production development.",
      "claudePrompt": "You are a system architect following ECC's architect protocol. Take the prototype code and refactor it into a clean, modular structure. Produce ADRs (Architecture Decision Records) for significant choices. Separate concerns, create proper module boundaries, add type definitions, and ensure the build system is solid. Don't add features — just restructure."
    },
    {
      "id": "backend_features",
      "assignTo": "coder",
      "depends": ["refactor_structure"],
      "description": "Implement all remaining backend features: {{ALL_BACKEND_FEATURES}}",
      "claudePrompt": "You are a senior backend developer following ECC's TDD workflow. For each feature: 1) Write failing tests first (RED), 2) Implement minimal code to pass (GREEN), 3) Refactor for quality (IMPROVE). Include proper error handling, input validation (no raw user input passes unchecked), and clean API responses with consistent envelope format. Use conventional commits: feat:, fix:, refactor:. No hardcoded secrets. Target 80%+ test coverage."
    },
    {
      "id": "frontend_features",
      "assignTo": "coder",
      "depends": ["refactor_structure"],
      "description": "Build complete UI with all features: {{ALL_FRONTEND_FEATURES}}",
      "claudePrompt": "You are a senior frontend developer following ECC's TDD workflow and frontend-patterns skill. Build the complete UI for {{PROJECT_NAME}} including: {{UI_FEATURE_LIST}}. Write component tests first. Implement proper state management, error states, loading states, and responsive design. Use conventional commits."
    },
    {
      "id": "tests",
      "assignTo": "tester",
      "depends": ["backend_features", "frontend_features"],
      "description": "Comprehensive test suite following ECC test standards.",
      "claudePrompt": "You are a QA engineer following ECC's testing standards. Write unit tests, integration tests, and E2E tests for {{PROJECT_NAME}}. Target 80%+ code coverage (ECC standard). Focus on: core business logic, API endpoints, error handling paths, edge cases, and critical user flows. Verify no regressions from prototype behavior. Use {{TEST_FRAMEWORK}}."
    },
    {
      "id": "code_review",
      "assignTo": "reviewer",
      "depends": ["backend_features", "frontend_features"],
      "description": "Code review following ECC review protocol.",
      "claudePrompt": "You are a senior code reviewer following ECC's code-review protocol. Review all code in {{PROJECT_NAME}} for: code quality, security (no hardcoded secrets, input validation, SQL injection, XSS), naming consistency, error handling completeness, test coverage, and conventional commit format. Rate each finding: CRITICAL / HIGH / MEDIUM / LOW. For each: describe issue, show location, suggest fix."
    },
    {
      "id": "cicd",
      "assignTo": "coder",
      "depends": ["tests"],
      "description": "Set up CI/CD pipeline.",
      "claudePrompt": "You are a DevOps engineer. Set up a CI/CD pipeline for {{PROJECT_NAME}} that: runs the full test suite, lints code, checks coverage (fail if below 80%), builds artifacts, and provides deployment instructions. Use {{CI_TOOL}} if specified, otherwise use GitHub Actions as default."
    },
    {
      "id": "documentation",
      "assignTo": "documenter",
      "depends": ["backend_features", "frontend_features", "tests"],
      "description": "Write complete project documentation following ECC doc-updater pattern.",
      "claudePrompt": "You are a technical writer following ECC's doc-updater protocol. Write documentation for {{PROJECT_NAME}} including: README with setup/run instructions, API documentation, architecture overview (with ADRs), and contributing guide. Ensure docs are synced with actual code — don't document features that don't exist or miss features that do. Make it clear enough that a new developer can get up and running in 10 minutes."
    }
  ]
}
```

### Stage 4: Production Workflow

All agents, including security and performance specialists.

```json
{
  "name": "stage-4-production",
  "description": "Production hardening for {{PROJECT_NAME}} — ECC security and review protocols",
  "tasks": [
    {
      "id": "security_audit",
      "assignTo": "analyst",
      "description": "Security audit following ECC's security-reviewer protocol.",
      "claudePrompt": "You are a security engineer following ECC's security-reviewer protocol. Perform a thorough security audit of {{PROJECT_NAME}}: 1) OWASP Top 10 review, 2) Dependency vulnerability scan (check for known CVEs), 3) Secret detection (grep for hardcoded API keys, tokens, passwords, connection strings), 4) Input validation review (all user inputs must be sanitized), 5) Authentication/authorization audit, 6) SQL injection and XSS checks. Rate each finding: CRITICAL / HIGH / MEDIUM / LOW. For each: describe the vulnerability, show the exact location, explain the attack vector, and provide a specific fix."
    },
    {
      "id": "performance_profile",
      "assignTo": "analyst",
      "description": "Performance profiling and benchmarking.",
      "claudePrompt": "You are a performance engineer. Profile {{PROJECT_NAME}} for: response times, memory usage, database query efficiency, and resource utilization. Identify bottlenecks and produce a report with optimization recommendations ranked by impact."
    },
    {
      "id": "security_fixes",
      "assignTo": "coder",
      "depends": ["security_audit"],
      "description": "Fix all critical and high severity security findings.",
      "claudePrompt": "You are a senior developer focused on security. Fix all critical and high severity findings from the security audit. For each fix: explain what was vulnerable, what the fix does, and how to verify it."
    },
    {
      "id": "performance_optimization",
      "assignTo": "optimizer",
      "depends": ["performance_profile"],
      "description": "Optimize identified bottlenecks.",
      "claudePrompt": "You are a performance optimization specialist. Address the top bottlenecks identified in the performance report. Focus on: query optimization, caching strategy, connection pooling, and any algorithmic improvements. Benchmark before and after each change."
    },
    {
      "id": "monitoring",
      "assignTo": "coder",
      "depends": ["security_fixes", "performance_optimization"],
      "description": "Add monitoring, logging, and alerting.",
      "claudePrompt": "You are a DevOps engineer. Add production monitoring to {{PROJECT_NAME}}: structured logging, health check endpoints, basic metrics (request count, latency, error rate), and alerting configuration. Keep it simple — use built-in tools where possible."
    },
    {
      "id": "final_tests",
      "assignTo": "tester",
      "depends": ["security_fixes", "performance_optimization"],
      "description": "Full regression test suite.",
      "claudePrompt": "You are a QA engineer running final regression tests. Run the complete test suite, verify all security fixes don't break functionality, and add any missing edge case tests. Produce a test report with pass/fail summary and coverage metrics."
    },
    {
      "id": "final_docs",
      "assignTo": "documenter",
      "depends": ["monitoring", "final_tests"],
      "description": "Complete production documentation.",
      "claudePrompt": "You are a technical writer. Finalize all documentation for production: deployment guide, monitoring runbook, incident response procedures, and update the README with production configuration. Include a changelog of all changes since MVP."
    },
    {
      "id": "final_review",
      "assignTo": "reviewer",
      "depends": ["monitoring", "final_tests", "final_docs"],
      "description": "Final code review and sign-off.",
      "claudePrompt": "You are the lead code reviewer doing a final review of {{PROJECT_NAME}} before production release. Check: all previous review items are addressed, security fixes are solid, performance changes don't introduce regressions, documentation is complete and accurate. Produce a final sign-off report."
    }
  ]
}
```

## Generating Workflow Configs

The CTO should customize these templates by replacing the `{{PLACEHOLDER}}` values with project-specific information from the product brief and architecture doc. Save the generated config as `project/workflow-stage-N.json`.

## Running Workflows

### Quick single-objective run (good for Stage 2)
```bash
$RUFLO_CMD hive-mind spawn "Build a prototype for [PROJECT]: [OBJECTIVE]" \
  --queen-type strategic \
  --claude \
  --non-interactive
```

### Full workflow run (good for Stages 3-4)
```bash
$RUFLO_CMD automation run-workflow project/workflow-stage-N.json \
  --claude \
  --non-interactive \
  --output-format stream-json
```

### Monitoring during execution
```bash
# Check status
$RUFLO_CMD hive-mind status

# View metrics
$RUFLO_CMD hive-mind metrics

# Check memory (shared context between agents)
$RUFLO_CMD hive-mind memory
```

## Fallback: When Ruflo Is Unavailable

If ruflo cannot be installed or fails to run (network issues, environment constraints), the CTO falls back to manual orchestration:

1. The CTO describes what each team member would do
2. Claude executes the tasks sequentially, role-playing each agent
3. The output quality is the same — just slower and without true parallelism
4. The CTO is transparent: "Ruflo isn't available in this environment, so I'm coordinating the team manually. Same result, just takes a bit longer."

This ensures the skill works even without ruflo installed — it degrades gracefully from parallel swarm execution to sequential single-agent execution.

## Shared Memory Pattern

For complex projects, agents need to share context. The CTO stores key decisions and artifacts in ruflo memory:

```bash
# Store the product brief for all agents to reference
$RUFLO_CMD memory store "product-brief" "$(cat project/product-brief.md)" --namespace project

# Store architecture decisions
$RUFLO_CMD memory store "architecture" "$(cat project/architecture.md)" --namespace project

# Store tech stack for consistent usage
$RUFLO_CMD memory store "tech-stack" '{"language":"rust","framework":"axum","database":"clickhouse"}' --namespace project

# Agents can query this during execution
$RUFLO_CMD memory query "tech stack" --namespace project
```
